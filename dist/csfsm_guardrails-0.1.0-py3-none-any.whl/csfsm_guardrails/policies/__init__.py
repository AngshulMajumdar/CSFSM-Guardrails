"""Packaged policy examples."""
